# -*- Mode: python; coding: utf-8; tab-width: 8; indent-tabs-mode: t; -*-

libsecret_enabled = True
rhythmbox_version = "3.4.6"

