# KCoreAddons

Qt addon library with a collection of non-GUI utilities

## Introduction

KCoreAddons provides classes built on top of QtCore to perform various tasks
such as manipulating mime types, autosaving files, creating backup files,
generating random sequences, performing text manipulations such as macro
replacement, accessing user information and many more.

