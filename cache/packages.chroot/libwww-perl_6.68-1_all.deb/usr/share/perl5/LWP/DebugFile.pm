package LWP::DebugFile;

our $VERSION = '6.68';

# legacy stub

1;
