The .synctex file specifications is now available as a man page with `man 5 synctex`.
