var E = require('./index.js');
module.exports = new E();
