default_policy.enable()
