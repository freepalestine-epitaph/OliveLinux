export const core: Record<string, any>;
export const languages: Record<string, any>;
export const plugins: Record<string, any>;
export const themes: Record<string, any>;
